import React from 'react';
import VoiceButton from '../components/VoiceButton';
import FeatureCard from '../components/FeatureCard';

export function Home({ onNavigate, onVoiceCommand, onOpenDoctorSuggest, t }) {
  return (
    <div className="home-page-container animate-fadeIn">
      {/* Top Greeting & Voice Assistance Hero */}
      <section className="home-hero">
        <h2 className="greeting-text">{t.greetingHeader}</h2>
        <p className="sub-greeting">{t.greetingSub}</p>
        
        {/* Central Large Microphone Voice Button */}
        <VoiceButton 
          onVoiceInput={(query) => {
            onVoiceCommand(query);
            onNavigate('talkToSaathi');
          }}
          t={t}
        />
      </section>

      {/* HEALTH & WELLNESS BANNER IMAGE CARD */}
      <section className="health-banner-card animate-fadeIn">
        <div className="health-banner-image-wrapper">
          <img 
            src="/images/health_hero.jpg" 
            alt="Elderly Indian Grandmother with Family and Caring Doctor" 
            className="health-banner-img"
          />
          <div className="health-banner-overlay-tag">
            <span>❤️ {t.appName} Health & Senior Care</span>
          </div>
        </div>
        <div className="health-banner-content">
          <h3 className="health-banner-title">
            {t.appName === 'SAATHI' ? 'Compassionate Senior Health & Care Companion' : 'आपका स्वास्थ्य और परिवार का साथी'}
          </h3>
          <p className="health-banner-desc">
            Built for easy daily health care: doctor prescription reader, medicine timing reminders, 24x7 hospital hotlines, and instant family alerts.
          </p>
        </div>
      </section>

      {/* Today's Reminder Card */}
      <section className="reminder-card">
        <div className="reminder-icon">☀️</div>
        <div className="reminder-content">
          <h3 className="reminder-title">{t.reminderTitle}</h3>
          <p className="reminder-text">{t.reminderNextText}</p>
        </div>
      </section>

      {/* Main Feature Cards Grid */}
      <section className="home-cards-grid">
        <FeatureCard 
          icon="🩺"
          title={t.btnDoctorSuggest || "Suggest Doctor by Disease"}
          description="Find recommended doctor specialists, tests, and top hospitals for your diagnosed condition."
          onClick={onOpenDoctorSuggest}
        />

        <FeatureCard 
          icon="🏥"
          title={t.cardHospitalsTitle || "India's Best Hospitals"}
          description={t.cardHospitalsDesc || "Top hospital directory & emergency numbers."}
          onClick={() => onNavigate('hospitals')}
        />

        <FeatureCard 
          icon="💊"
          title={t.cardMedicinesTitle}
          description={t.cardMedicinesDesc}
          onClick={() => onNavigate('medicines')}
        />

        <FeatureCard 
          icon="🩺"
          title={t.navVitals || "Patient Vitals & Pulse Rate"}
          description="Count daily footsteps, distance, and measure live optical PPG heart rate."
          onClick={() => onNavigate('vitals')}
        />

        <FeatureCard 
          icon="📱"
          title={t.cardPhoneHelpTitle}
          description={t.cardPhoneHelpDesc}
          onClick={() => onNavigate('phoneHelp')}
        />

        <FeatureCard 
          icon="👨‍👩‍👧"
          title={t.cardFamilyTitle}
          description={t.cardFamilyDesc}
          onClick={() => onNavigate('familyDashboard')}
        />
      </section>
    </div>
  );
}

export default Home;
