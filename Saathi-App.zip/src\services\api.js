// Mock API service layer structured for seamless future backend integration.
// Supports English, Hindi, Bengali and Assamese

export const api = {
  // GET /api/medicines
  async getMedicines() {
    await new Promise((res) => setTimeout(res, 300));
    return [
      {
        id: "med-1",
        time: "8:00 AM",
        name: "Medicine A",
        dosage: "1 tablet",
        purpose: "Blood Pressure / BP",
        status: "taken", // "taken" | "upcoming" | "missed"
        icon: "💊",
      },
      {
        id: "med-2",
        time: "2:00 PM",
        name: "Medicine B",
        dosage: "1 tablet",
        purpose: "Multivitamin",
        status: "upcoming",
        icon: "💊",
      },
      {
        id: "med-3",
        time: "9:00 PM",
        name: "Medicine C",
        dosage: "1 tablet",
        purpose: "Diabetes Care",
        status: "upcoming",
        icon: "💊",
      },
    ];
  },

  // POST /api/medicine/taken
  async markMedicineTaken(medicineId) {
    await new Promise((res) => setTimeout(res, 200));
    return { success: true, medicineId, status: "taken" };
  },

  // POST /api/ask
  async askSaathi(query, lang = "en") {
    await new Promise((res) => setTimeout(res, 1200));
    const normalized = query.toLowerCase();

    if (lang === "bn") {
      if (normalized.includes("photo") || normalized.includes("whatsapp")) {
        return {
          answer: "অবশ্যই! হোয়াটসঅ্যাপে ছবি পাঠাতে: ১) চ্যাট খুলুন, ২) নিচে ক্যামেরা (📷) আইকন টিপুন, ৩) ছবি বেছে নিয়ে সবুজ বোতাম টিপুন।",
          audioText: "অবশ্যই! আমি আপনাকে ধাপে ধাপে বুঝিয়ে দিচ্ছি। হোয়াটসঅ্যাপ চ্যাট খুলে নিচে ক্যামেরা বোতাম টিপুন।",
        };
      }
      if (normalized.includes("medicine") || normalized.includes("dawai") || normalized.includes("prescription")) {
        return {
          answer: "আপনার প্রেসক্রিপশনের ওষুধ: ১) টেলমিসারটান (সকাল ৮:০০), ২) প্যান্টোপ্রাজল (সকাল ৭:৩০), ৩) মেটফর্মিন (দুপুর ১:৩০), ৪) অ্যাটরভাস্ট্যাটিন (রাত ৯:০০)।",
          audioText: "আপনার প্রেসক্রিপশনে ৪টি ওষুধ পাওয়া গেছে। সকালের ওষুধ ৭:৩০ ও ৮:০০ টায়, দুপুরের ওষুধ ১:৩০ টায় এবং রাতের ওষুধ ৯:০০ টায়।",
        };
      }
      return {
        answer: "নমস্কার! আমি সাথী। আপনি আমাকে প্রেসক্রিপশন, ওষুধ বা ফোন ব্যবহার বিষয়ে যেকোনো কিছু জিজ্ঞাসা করতে পারেন।",
        audioText: "নমস্কার! আমি সাথী। আজ আমি আপনাকে কীভাবে সাহায্য করতে পারি?",
      };
    } else if (lang === "as") {
      if (normalized.includes("photo") || normalized.includes("whatsapp")) {
        return {
          answer: "নিশ্চয়ই! হোৱাটছএপত ফটো পঠিয়াবলৈ: ১) চেট খোলক, ২) তলত কেমেৰা (📷) আইকন টিপক, ৩) ফটো বাছি লৈ সেউজীয়া বটম টিপক।",
          audioText: "নিশ্চয়ই! মই আপোনাক খোজ ক্ৰমে বুজাই দিছোঁ। হোৱাটছএপ চেট খুলি তলৰ কেমেৰা বটম টিপক।",
        };
      }
      if (normalized.includes("medicine") || normalized.includes("dawai") || normalized.includes("prescription")) {
        return {
          answer: "আপোনাৰ প্ৰে ক্ৰিপচনৰ ঔষধ: ১) টেলমিচাৰটান (ৰাতিপুৱা ৮:০০), ২) পেন্টোপ্ৰাজল (ৰাতিপুৱা ৭:৩০), ৩) মেটফৰমিন (দুপৰীয়া ১:৩০), ৪) এটৰভাষ্টেটিন (ৰাতি ৯:০০)।",
          audioText: "আপোনাৰ প্ৰে ক্ৰিপচনত ৪ টা ঔষধ পোৱা গৈছে। ৰাতিপুৱাৰ ঔষধ ৭:৩০ আৰু ৮:০০ বজাত, দুপৰীয়াৰ ঔষধ ১:৩০ বজাত আৰু ৰাতিৰ ঔষধ ৯:০০ বজাত।",
        };
      }
      return {
        answer: "নমস্কাৰ! মই সাথী। আপুনি মোক প্ৰে ক্ৰিপচন, ঔষধ বা ফোন চলোৱাৰ বিষয়ে যিকোনো প্ৰশ্ন সুধিব পাৰে।",
        audioText: "নমস্কাৰ! মই সাথী। আজি মই আপোনাক কেনেকৈ সহায় কৰিব পাৰোঁ?",
      };
    } else if (lang === "hi") {
      if (normalized.includes("photo") || normalized.includes("whatsapp")) {
        return {
          answer: "बिल्कुल! व्हाट्सएप पे फोटो भेजने के लिए: 1) चैट खोलें, 2) नीचे कैमरा (📷) आइकन दबाएं, 3) अपनी फोटो चुनें और हरा बटन दबाएं।",
          audioText: "बिलकुल. मैं आपको एक-एक स्टेप करके बताती हूँ. व्हाट्सएप पे फोटो भेजने के लिए चैट खोलें और नीचे कैमरा आइकन दबाएं.",
        };
      }
      if (normalized.includes("dawai") || normalized.includes("medicine") || normalized.includes("prescription")) {
        return {
          answer: "आपकी पर्ची की दवाइयाँ: 1) टेल्मीसार्टन (8:00 AM), 2) पेंटोप्राजोल (7:30 AM), 3) मेटफॉर्मिन (1:30 PM), 4) एटोरवास्टेटिन (9:00 PM)।",
          audioText: "आपकी पर्ची में चार दवाइयाँ मिली हैं. सुबह की दवा 7:30 और 8:00 बजे, दोपहर की दवा 1:30 बजे और रात की दवा 9:00 बजे लेनी है.",
        };
      }
      return {
        answer: "नमस्ते! मैं साथी हूँ। आप मुझसे डॉक्टर के पर्चे (Prescription), फ़ोन चलाने या दवाइयों के समय के बारे में कुछ भी पूछ सकते हैं।",
        audioText: "नमस्ते! मैं साथी हूँ. बताइए मैं आज आपकी क्या मदद कर सकती हूँ?",
      };
    } else {
      if (normalized.includes("photo") || normalized.includes("whatsapp")) {
        return {
          answer: "Sure! To send a photo on WhatsApp: 1) Open the chat, 2) Tap the camera 📷 icon at the bottom, 3) Select your photo and press the green send button.",
          audioText: "Sure! I will guide you step by step. Open WhatsApp, tap the camera icon, select your photo and press send.",
        };
      }
      if (normalized.includes("medicine") || normalized.includes("prescription")) {
        return {
          answer: "Prescription breakdown: 1) Telmisartan (8:00 AM), 2) Pantoprazole (7:30 AM), 3) Metformin (1:30 PM), 4) Atorvastatin (9:00 PM). Click 'Add to Schedule' to auto-save them.",
          audioText: "I found four medicines in your doctor prescription. Morning dose at 7:30 AM and 8:00 AM, lunch dose at 1:30 PM and night dose at 9:00 PM.",
        };
      }
      return {
        answer: "Hello! I am SAATHI, your friendly digital companion. You can upload doctor prescriptions, ask about medicines, or get phone guidance.",
        audioText: "Hello! I am SAATHI. How can I help you today?",
      };
    }
  },

  // POST /api/analyze-prescription (Doctor Prescription Reader)
  async analyzePrescription(imageSource) {
    await new Promise((res) => setTimeout(res, 1800));

    return {
      isPrescription: true,
      titleEn: "Doctor Prescription Analysis & Breakdown",
      titleHi: "डॉक्टर के पर्चे (Prescription) का विवरण",
      titleBn: "ডাক্তারের প্রেসক্রিপশন বিশ্লেষণ",
      titleAs: "ডাক্তৰৰ প্ৰে ক্ৰিপচন বিশ্লেষণ",
      doctorName: "Dr. A. K. Sharma (MD, Senior Cardiologist)",
      clinicName: "Apollo Heart & Health Clinic",
      patientName: "Patient Care Record",
      date: "13 Aug 2026",
      medicines: [
        {
          id: "presc-med-1",
          name: "Telmisartan 40mg",
          dosage: "1 tablet",
          time: "8:00 AM",
          timingDetailEn: "Before Breakfast",
          timingDetailHi: "नाश्ते से पहले",
          timingDetailBn: "প্রাতরাশের আগে",
          timingDetailAs: "ৰাতিপুৱাৰ আহাৰৰ আগতে",
          purpose: "Blood Pressure / BP",
          status: "upcoming",
          icon: "💊"
        },
        {
          id: "presc-med-2",
          name: "Pantoprazole 40mg",
          dosage: "1 tablet",
          time: "7:30 AM",
          timingDetailEn: "Empty Stomach",
          timingDetailHi: "खाली पेट (सुबह)",
          timingDetailBn: "খালি পেটে (সকালে)",
          timingDetailAs: "খালি পেটত (ৰাতিপুৱা)",
          purpose: "Acidity & Stomach Protection",
          status: "upcoming",
          icon: "💊"
        },
        {
          id: "presc-med-3",
          name: "Metformin 500mg",
          dosage: "1 tablet",
          time: "1:30 PM",
          timingDetailEn: "After Lunch",
          timingDetailHi: "दोपहर के खाने के बाद",
          timingDetailBn: "দুপুরের খাবারের পর",
          timingDetailAs: "দুপৰীয়াৰ আহাৰৰ পিছত",
          purpose: "Diabetes & Blood Sugar",
          status: "upcoming",
          icon: "💊"
        },
        {
          id: "presc-med-4",
          name: "Atorvastatin 10mg",
          dosage: "1 tablet",
          time: "9:00 PM",
          timingDetailEn: "After Dinner (At Bedtime)",
          timingDetailHi: "रात के खाने के बाद",
          timingDetailBn: "রাতের খাবারের পর",
          timingDetailAs: "ৰাতিৰ আহাৰৰ পিছত",
          purpose: "Cholesterol & Heart Care",
          status: "upcoming",
          icon: "💊"
        }
      ],
      instructionsEn: "Take Pantoprazole with warm water on empty stomach. Avoid oily foods and salt intake. Follow up after 7 days.",
      instructionsHi: "पेंटोप्राजोल सुबह गुनगुने पानी के साथ खाली पेट लें। ज्यादा तला-भुना और नमक कम खाएं। 7 दिनों के बाद दोबारा दिखाएं।",
      instructionsBn: "প্যান্টোপ্রাজল সকালে হালকা গরম জলের সাথে খালি পেটে খাবেন। তেল-ঝাল ও অতিরিক্ত লবণ এড়িয়ে চলুন। ৭ দিন পর ডাক্তার দেখান।",
      instructionsAs: "পেন্টোপ্ৰাজল ৰাতিপুৱা ঈষদুষ্ণ পানীৰ সৈতে খালি পেটত খাব। তেলযুক্ত খাদ্য আৰু অতিৰিক্ত নিমখ পৰিহাৰ কৰিব। ৭ দিনৰ পিছত পুনৰ দেখুৱাব।",
      audioSummaryEn: "Doctor Sharma prescribed 4 medicines: Pantoprazole at 7:30 AM, Telmisartan at 8:00 AM, Metformin at 1:30 PM, and Atorvastatin at 9:00 PM.",
      audioSummaryHi: "डॉक्टर शर्मा के पर्चे में 4 दवाइयाँ हैं: सुबह 7:30 बजे पेंटोप्राजोल खाली पेट, 8:00 बजे टेल्मीसार्टन नाश्ते से पहले, दोपहर 1:30 बजे मेटफॉर्मिन और रात 9:00 बजे एटोरवास्टेटिन।",
      audioSummaryBn: "ডাক্তার শর্মার প্রেসক্রিপশনে ৪টি ওষুধ রয়েছে: সকালে ৭:৩০ টায় প্যান্টোপ্রাজল খালি পেটে, ৮:০০ টায় টেলমিসারটান, দুপুরে ১:৩০ টায় মেটফর্মিন এবং রাতে ৯:০০ টায় অ্যাটরভাস্ট্যাটিন।",
      audioSummaryAs: "ডাক্তৰ শৰ্মাৰ প্ৰে ক্ৰিপচনত ৪ টা ঔষধ আছে: ৰাতিপুৱা ৭:৩০ বজাত পেন্টোপ্ৰাজল খালি পেটত, ৮:০০ বজাত টেলমিচাৰটান, দুপৰীয়া ১:৩০ বজাত মেটফৰমিন আৰু ৰাতি ৯:০০ বজাত এটৰভাষ্টেটিন।"
    };
  },

  // POST /api/analyze-screen
  async analyzeScreen(imageSource, promptType = "general") {
    await new Promise((res) => setTimeout(res, 1800));

    if (promptType === "prescription" || imageSource.includes("prescription") || imageSource.includes("parcha")) {
      return this.analyzePrescription(imageSource);
    }

    return {
      title: "Screen Guidance",
      steps: [
        {
          stepNumber: 1,
          totalSteps: 3,
          instruction: "Tap the green highlighted button in the top right corner.",
          instructionHi: "ऊपर दाएं कोने में हरे रंग से हाइलाइट किए गए बटन पर टैप करें।",
          instructionBn: "উপরে ডান কোণায় সবুজ রঙের বোতামে আলতো চাপুন।",
          instructionAs: "ওপৰৰ সোঁ ফালৰ সেউজীয়া ৰঙৰ বটমত টিপক।",
          targetBox: { x: 70, y: 12, width: 20, height: 10 },
          pointerDirection: "top-right",
        },
        {
          stepNumber: 2,
          totalSteps: 3,
          instruction: "Select your recipient or contact from the list shown.",
          instructionHi: "सूची में से अपने संपर्क या व्यक्ति का नाम चुनें।",
          instructionBn: "তালিকা থেকে আপনার যোগাযোগের নাম নির্বাচন করুন।",
          instructionAs: "তালিকাৰ পৰা আপোনাৰ যোগাযোগ বাছক।",
          targetBox: { x: 15, y: 35, width: 70, height: 25 },
          pointerDirection: "center",
        },
        {
          stepNumber: 3,
          totalSteps: 3,
          instruction: "Press the paper plane or Send button (📤) to finish.",
          instructionHi: "भेजने के लिए कागज़ के विमान या Send बटन (📤) को दबाएं।",
          instructionBn: "পাঠাতে সেন্ড বোতাম (📤) চাপুন।",
          instructionAs: "পঠিয়াবলৈ চেন্দ বটম (📤) টিপক।",
          targetBox: { x: 75, y: 80, width: 15, height: 10 },
          pointerDirection: "bottom-right",
        },
      ],
    };
  },

  async getFamilyDashboard() {
    await new Promise((res) => setTimeout(res, 300));
    return {
      medicinesTakenCount: 4,
      medicinesTotalCount: 5,
      techHelpRequestsCount: 2,
      urgentAlertsCount: 0,
      todayActivity: [
        { time: "8:00 AM", medicine: "Medicine A (1 tablet)", status: "taken", label: "✓ Taken" },
        { time: "2:00 PM", medicine: "Medicine B (1 tablet)", status: "missed", label: "✕ Missed" },
        { time: "9:00 PM", medicine: "Medicine C (1 tablet)", status: "upcoming", label: "⏳ Upcoming" },
      ],
    };
  },
};
