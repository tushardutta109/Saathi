import React, { useState, useEffect } from 'react';
import { voiceService } from '../services/voiceService';
import Modal from '../components/Modal';

export function VitalsMonitor({ lang = 'hi', t, onAddNotification }) {
  // 1. Footstep Counter States
  const [steps, setSteps] = useState(4280);
  const [stepGoal, setStepGoal] = useState(6000);
  const [isAutoWalking, setIsAutoWalking] = useState(false);
  const [lastStepTime, setLastStepTime] = useState(Date.now());

  // 2. Heart Rate / Pulse Monitor States
  const [heartRate, setHeartRate] = useState(74); // BPM
  const [isMeasuringPulse, setIsMeasuringPulse] = useState(false);
  const [measureProgress, setMeasureProgress] = useState(0);
  const [pulseHistory, setPulseHistory] = useState([72, 74, 71, 75, 74]);
  const [isLowPulseModalOpen, setIsLowPulseModalOpen] = useState(false);

  // Play Audible Dual-Tone Emergency Siren Sound (Web Audio API)
  const playEmergencySiren = () => {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      // Alternating high/low siren frequencies over 1.8 seconds
      osc.frequency.setValueAtTime(880, now);
      osc.frequency.setValueAtTime(440, now + 0.2);
      osc.frequency.setValueAtTime(880, now + 0.4);
      osc.frequency.setValueAtTime(440, now + 0.6);
      osc.frequency.setValueAtTime(880, now + 0.8);
      osc.frequency.setValueAtTime(440, now + 1.0);
      osc.frequency.setValueAtTime(880, now + 1.2);

      gain.gain.setValueAtTime(0.4, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 1.8);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 1.8);
    } catch (e) {
      console.warn('Web Audio Siren Exception:', e);
    }
  };

  // Trigger Full Emergency Alarm Suite for Low Pulse Rate
  const triggerLowPulseAlarm = (bpmVal) => {
    // 1. Play Emergency Siren Sound
    playEmergencySiren();

    // 2. Haptic Phone Vibration
    if (typeof window !== 'undefined' && window.navigator && window.navigator.vibrate) {
      try {
        window.navigator.vibrate([400, 200, 400, 200, 500, 200, 800]);
      } catch (e) {}
    }

    // 3. Spoken Voice Emergency Announcement in Patient's Language
    const voiceMsg = t.lowPulseVoiceText || "Attention! Dangerously low pulse rate detected. Please sit down immediately, rest, and call for emergency help.";
    voiceService.speak(voiceMsg, lang);

    // 4. Open Urgent Low Pulse Emergency Modal
    setIsLowPulseModalOpen(true);

    // 5. Add Emergency Notification
    if (onAddNotification) {
      onAddNotification({
        title: `🚨 LOW PULSE CRITICAL ALARM: ${bpmVal} BPM`,
        message: t.lowPulseAlarmMsg || `Pulse rate dropped to ${bpmVal} BPM! Call 108 Emergency Ambulance immediately.`,
        icon: '🚨',
        type: 'emergency'
      });
    }
  };

  // Accelerometer DeviceMotion step detection
  useEffect(() => {
    let lastAccel = 0;
    const handleMotion = (event) => {
      const acc = event.accelerationIncludingGravity;
      if (!acc) return;
      
      const totalAccel = Math.sqrt((acc.x || 0) ** 2 + (acc.y || 0) ** 2 + (acc.z || 0) ** 2);
      const delta = Math.abs(totalAccel - lastAccel);
      
      // Step threshold
      if (delta > 11.5) {
        const now = Date.now();
        if (now - lastStepTime > 350) {
          setSteps((prev) => prev + 1);
          setLastStepTime(now);
        }
      }
      lastAccel = totalAccel;
    };

    if (window.DeviceMotionEvent) {
      window.addEventListener('devicemotion', handleMotion);
    }
    return () => {
      if (window.DeviceMotionEvent) {
        window.removeEventListener('devicemotion', handleMotion);
      }
    };
  }, [lastStepTime]);

  // Auto-Walking simulation timer
  useEffect(() => {
    let interval = null;
    if (isAutoWalking) {
      interval = setInterval(() => {
        setSteps((prev) => prev + 2);
      }, 800);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isAutoWalking]);

  // Calculate metrics
  const distanceKm = (steps * 0.00075).toFixed(2); // ~0.75m per step
  const caloriesKcal = Math.round(steps * 0.04);
  const activeMinutes = Math.round(steps / 100);
  const progressPercent = Math.min(Math.round((steps / stepGoal) * 100), 100);

  // Heart Rate Status Categorization
  const getHeartRateStatus = (bpm) => {
    if (bpm < 50) {
      return {
        label: t.bpmStatusVeryLow || '🚨 DANGEROUSLY LOW PULSE (< 50 BPM) - EMERGENCY ALARM!',
        color: '#ffffff',
        bg: 'var(--red-alert)',
        type: 'critical_low'
      };
    } else if (bpm < 60) {
      return {
        label: t.bpmStatusResting || '💙 Resting Pulse (50-60 BPM)',
        color: 'var(--primary-forest)',
        bg: 'var(--bg-secondary)',
        type: 'resting'
      };
    } else if (bpm <= 100) {
      return {
        label: t.bpmStatusNormal || '💚 Normal & Healthy (60-100 BPM)',
        color: 'var(--green-success)',
        bg: 'var(--green-success-bg)',
        type: 'normal'
      };
    } else {
      return {
        label: t.bpmStatusHigh || '❤️ High Pulse Rate (>100 BPM) - Rest Recommended',
        color: 'var(--red-alert)',
        bg: 'var(--red-alert-bg)',
        type: 'high'
      };
    }
  };

  const currentPulseStatus = getHeartRateStatus(heartRate);

  // Trigger 10-second Live Optical Heart Rate Scan
  const handleMeasureHeartRate = () => {
    if (isMeasuringPulse) return;

    setIsMeasuringPulse(true);
    setMeasureProgress(0);

    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setMeasureProgress(progress);

      // Fluctuate heart rate live during scan
      const randomBpm = 68 + Math.floor(Math.random() * 16);
      setHeartRate(randomBpm);

      if (progress >= 100) {
        clearInterval(interval);
        setIsMeasuringPulse(false);

        const finalBpm = 72 + Math.floor(Math.random() * 12);
        setHeartRate(finalBpm);
        setPulseHistory((prev) => [...prev.slice(1), finalBpm]);

        if (onAddNotification) {
          onAddNotification({
            title: `🩺 Heart Rate Measured: ${finalBpm} BPM`,
            message: `Pulse Status: ${finalBpm <= 100 ? 'Normal / Healthy' : 'Elevated'}`,
            icon: '💖',
            type: 'success'
          });
        }
      }
    }, 400);
  };

  // Simulate Low Pulse Emergency (45 BPM)
  const handleSimulateLowPulse = () => {
    const lowPulseVal = 45;
    setHeartRate(lowPulseVal);
    setPulseHistory((prev) => [...prev.slice(1), lowPulseVal]);
    triggerLowPulseAlarm(lowPulseVal);
  };

  const handleSimulateSteps = (count = 50) => {
    setSteps((prev) => prev + count);
  };

  const handleResetSteps = () => {
    setSteps(0);
  };

  // Voice Readout of Patient Vitals & Health Cautions
  const handleSpeakVitals = () => {
    let text = '';
    if (heartRate < 50) {
      text = t.lowPulseVoiceText || `Dangerously low pulse detected. Your pulse is ${heartRate} BPM. Please sit down immediately and seek emergency medical assistance.`;
    } else if (lang === 'hi') {
      text = `मरीज़ का हेल्थ रिपोर्ट: आज आप ${steps} कदम चले हैं, जो लगभग ${distanceKm} किलोमीटर है। आपकी दिल की धड़कन ${heartRate} बीपीएम है। स्वस्थ रहने के लिए रोज़ 6000 कदम चलें।`;
    } else if (lang === 'bn') {
      text = `রোগীর স্বাস্থ্য রিপোর্ট: আজ আপনি ${steps} টি পদক্ষেপ হেঁটেছেন, যা প্রায় ${distanceKm} কিলোমিটার। আপনার হৃদস্পন্দন মিনিটে ${heartRate} বিপিএম। সুস্থ থাকতে প্রতিদিন ৬০০০ পদক্ষেপ হাঁটুন।`;
    } else if (lang === 'as') {
      text = `ৰোগীৰ স্বাস্থ্য ৰিপৰ্ট: আজি আপুনি ${steps} টা খোজ কাঢ়িছে, যি প্ৰায় ${distanceKm} কিলোমিটাৰ। আপোনাৰ হৃদস্পন্দন মিনিটত ${heartRate} বিপিএম।`;
    } else {
      text = `Patient Vitals Report: You have walked ${steps} steps today, covering ${distanceKm} kilometers. Your heart rate is ${heartRate} BPM.`;
    }

    voiceService.speak(text, lang);
  };

  return (
    <div className="vitals-monitor-page animate-fadeIn">
      {/* Header Banner */}
      <div className="vitals-hero-header">
        <div className="hero-title-group">
          <span className="hero-icon-badge">🩺</span>
          <div>
            <h2 className="hero-main-title">{t.vitalsTitle || "Patient Footstep Counter & Live Heart Rate Monitor"}</h2>
            <p className="hero-sub-title">{t.vitalsSub || "Accurate real-time health tracking for daily mobility and heart pulse."}</p>
          </div>
        </div>

        <button className="btn-listen-speech-large" onClick={handleSpeakVitals}>
          🔊 {t.btnListenVitalsAudio || "Listen Vitals Summary Aloud"}
        </button>
      </div>

      {/* Critical Low Pulse Emergency Banner if pulse < 50 */}
      {heartRate < 50 && (
        <div className="low-pulse-alert-banner animate-pulse">
          <div className="alert-banner-header">
            <span className="alert-badge-icon">🚨</span>
            <h3 className="alert-banner-title">
              {t.lowPulseAlarmTitle || "CRITICAL WARNING: Dangerously Low Pulse Detected (< 50 BPM)!"}
            </h3>
          </div>
          <p className="alert-banner-msg">
            {t.lowPulseAlarmMsg || "Your heart rate has dropped to a critical low level. Sit down immediately, drink water, and call 108 Emergency Ambulance."}
          </p>
          <div className="alert-banner-actions">
            <a href="tel:108" className="btn-alert-call-108">
              🚑 Call 108 Free Emergency Ambulance
            </a>
            <button className="btn-alert-dismiss" onClick={() => setIsLowPulseModalOpen(true)}>
              🆘 Emergency Hotline Menu
            </button>
          </div>
        </div>
      )}

      <div className="vitals-cards-grid">
        {/* ===================================================================
            1. FOOTSTEP COUNTER CARD
           =================================================================== */}
        <div className="vitals-card step-counter-card">
          <div className="card-top-row">
            <div className="card-title-group">
              <span className="card-icon">👟</span>
              <div>
                <h3 className="card-heading">{t.stepsCardTitle || "Footstep Counter (कदमों की गिनती)"}</h3>
                <span className="card-subtext">{t.stepsGoal || "Daily Target: 6,000 Steps"}</span>
              </div>
            </div>
            <span className="goal-badge">{progressPercent}% Goal</span>
          </div>

          {/* Large Step Count Display */}
          <div className="step-count-hero">
            <span className="step-number-text">{steps.toLocaleString()}</span>
            <span className="step-unit-text">STEPS WALKED TODAY</span>
          </div>

          {/* Progress Bar */}
          <div className="step-progress-track">
            <div className="step-progress-fill" style={{ width: `${progressPercent}%` }}></div>
          </div>

          {/* 3 Metric Pills */}
          <div className="step-metrics-grid">
            <div className="metric-pill">
              <span className="metric-icon">🗺️</span>
              <div className="metric-info">
                <span className="metric-val">{distanceKm} km</span>
                <span className="metric-lbl">{t.distanceLabel || "Distance"}</span>
              </div>
            </div>

            <div className="metric-pill">
              <span className="metric-icon">🔥</span>
              <div className="metric-info">
                <span className="metric-val">{caloriesKcal} kcal</span>
                <span className="metric-lbl">{t.caloriesLabel || "Calories"}</span>
              </div>
            </div>

            <div className="metric-pill">
              <span className="metric-icon">⏱️</span>
              <div className="metric-info">
                <span className="metric-val">{activeMinutes} mins</span>
                <span className="metric-lbl">{t.activeTimeLabel || "Walk Time"}</span>
              </div>
            </div>
          </div>

          {/* Interactive Step Actions */}
          <div className="step-actions-bar">
            <button className="btn-step-action primary" onClick={() => handleSimulateSteps(50)}>
              👟 {t.btnSimulateStep || "+ Walk 50 Steps"}
            </button>

            <button 
              className={`btn-step-action ${isAutoWalking ? 'active-walk' : 'secondary'}`} 
              onClick={() => setIsAutoWalking(!isAutoWalking)}
            >
              {isAutoWalking ? '⏹️ Stop Auto-Walk' : '▶️ Live Walking Mode'}
            </button>

            <button className="btn-step-action danger" onClick={handleResetSteps}>
              ↺ {t.btnResetSteps || "Reset"}
            </button>
          </div>
        </div>

        {/* ===================================================================
            2. REAL-TIME HEART RATE / ECG MONITOR CARD
           =================================================================== */}
        <div className={`vitals-card heart-rate-card ${heartRate < 50 ? 'heart-card-critical' : ''}`}>
          <div className="card-top-row">
            <div className="card-title-group">
              <span className={`pulsing-heart-icon ${isMeasuringPulse ? 'fast-pulse' : ''} ${heartRate < 50 ? 'slow-pulse-warning' : ''}`}>
                {heartRate < 50 ? '⚠️' : '💖'}
              </span>
              <div>
                <h3 className="card-heading">{t.heartRateTitle || "Live Heart Rate & Pulse Monitor"}</h3>
                <span className="card-subtext">Optical PPG & Emergency Pulse Alarm</span>
              </div>
            </div>
            <span className={`sensor-live-pill ${heartRate < 50 ? 'critical-pill' : ''}`}>
              {heartRate < 50 ? '🚨 ALARM ACTIVE' : '● LIVE PPG'}
            </span>
          </div>

          {/* Heart Rate Display */}
          <div className="heart-rate-display">
            <div className="bpm-number-group">
              <span className={`bpm-value ${heartRate < 50 ? 'bpm-critical-text' : ''}`}>{heartRate}</span>
              <span className="bpm-unit">BPM</span>
            </div>

            {/* Status Pill */}
            <div className="bpm-status-banner" style={{ backgroundColor: currentPulseStatus.bg, color: currentPulseStatus.color }}>
              {currentPulseStatus.label}
            </div>
          </div>

          {/* ECG Pulse Wave Graph Visualizer */}
          <div className="ecg-graph-box">
            <svg className="ecg-svg" viewBox="0 0 400 60" preserveAspectRatio="none">
              <path 
                className={`ecg-line ${heartRate < 50 ? 'ecg-line-warning' : ''}`} 
                d="M 0 30 L 50 30 L 60 10 L 70 50 L 80 20 L 90 35 L 100 30 L 150 30 L 160 10 L 170 50 L 180 20 L 190 35 L 200 30 L 250 30 L 260 10 L 270 50 L 280 20 L 290 35 L 300 30 L 350 30 L 360 10 L 370 50 L 380 20 L 390 35 L 400 30" 
              />
            </svg>
          </div>

          {/* Pulse Measuring Scan Progress Bar */}
          {isMeasuringPulse && (
            <div className="pulse-measuring-container">
              <span className="measuring-text">
                {t.measuringPulseText || "Analyzing PPG Optical Sensor & Pulse Wave..."}
              </span>
              <div className="measure-bar-track">
                <div className="measure-bar-fill" style={{ width: `${measureProgress}%` }}></div>
              </div>
            </div>
          )}

          {/* Recent Pulse Readings */}
          <div className="pulse-history-row">
            <span className="history-label">Recent Heart Rate Log:</span>
            <div className="history-chips">
              {pulseHistory.map((val, idx) => (
                <span key={idx} className={`pulse-history-chip ${val < 50 ? 'chip-critical' : ''}`}>
                  {val} BPM
                </span>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="heart-actions-bar">
            <button 
              className={`btn-measure-pulse ${isMeasuringPulse ? 'measuring' : ''}`}
              onClick={handleMeasureHeartRate}
              disabled={isMeasuringPulse}
            >
              🩺 {isMeasuringPulse ? `Measuring... ${measureProgress}%` : (t.btnMeasurePulse || "Measure Live Pulse Rate")}
            </button>

            {/* Test Low Pulse Emergency Alarm Button */}
            <button 
              className="btn-test-low-pulse"
              onClick={handleSimulateLowPulse}
            >
              {t.btnTestLowPulse || "🚨 Test Low Pulse Emergency (45 BPM)"}
            </button>
          </div>
        </div>
      </div>

      {/* ===================================================================
          3. HEALTHY vs NOT HEALTHY MEDICAL CAUTION GUIDANCE
         =================================================================== */}
      <div className="vitals-guidance-section animate-fadeIn">
        <h3 className="section-title-label" style={{ fontSize: '26px', marginBottom: '20px', color: 'var(--primary-forest)' }}>
          🩺 Patient Health Guidance: Healthy Range vs Not Healthy Cautions
        </h3>

        <div className="guidance-cards-grid">
          {/* Healthy Habits & Ranges (Green Card) */}
          <div className="guidance-card healthy-card">
            <div className="guidance-header green">
              <span className="guidance-icon">🟢</span>
              <h4 className="guidance-title">
                {t.healthyTitle || "Healthy Range & Habits (स्वस्थ आदतें)"}
              </h4>
            </div>

            <ul className="guidance-list">
              <li className="guidance-item">
                <span className="item-bullet">✓</span>
                <div>
                  <strong>Daily Footsteps (6,000+ steps/day):</strong>
                  <p>{t.stepsHealthyAdvice || "Walking 6,000+ steps daily improves blood circulation, lowers blood pressure, and keeps joints flexible."}</p>
                </div>
              </li>

              <li className="guidance-item">
                <span className="item-bullet">✓</span>
                <div>
                  <strong>Normal Resting Pulse (60 - 100 BPM):</strong>
                  <p>{t.pulseHealthyAdvice || "Resting Heart Rate between 60 - 100 BPM indicates optimal cardiovascular function."}</p>
                </div>
              </li>

              <li className="guidance-item">
                <span className="item-bullet">✓</span>
                <div>
                  <strong>Hydration & Routine Walk:</strong>
                  <p>Drinking 2.5 Liters of water daily and light 20-minute morning walks maintain energy levels.</p>
                </div>
              </li>

              <li className="guidance-item">
                <span className="item-bullet">✓</span>
                <div>
                  <strong>7-8 Hours Restful Sleep:</strong>
                  <p>Adequate nighttime sleep helps keep resting heart rate and blood pressure stable.</p>
                </div>
              </li>
            </ul>
          </div>

          {/* Not Healthy & Caution Alerts (Red Alert Card) */}
          <div className="guidance-card caution-card">
            <div className="guidance-header red">
              <span className="guidance-icon">🔴</span>
              <h4 className="guidance-title">
                {t.unhealthyTitle || "Not Healthy & Caution Alerts (अस्वास्थ्यकर संकेत)"}
              </h4>
            </div>

            <ul className="guidance-list">
              <li className="guidance-item">
                <span className="item-bullet alert">⚠️</span>
                <div>
                  <strong>Low Daily Mobility (&lt; 2,000 steps/day):</strong>
                  <p>{t.stepsCautionAdvice || "Walking under 2,000 steps daily can cause muscle weakness and lethargy. Try light 10-minute walks."}</p>
                </div>
              </li>

              <li className="guidance-item">
                <span className="item-bullet alert">🚨</span>
                <div>
                  <strong>High Pulse Rate (&gt; 100 BPM Tachycardia):</strong>
                  <p>{t.pulseCautionAdvice || "Heart rate consistently above 100 BPM while at rest requires immediate sitting down and doctor consultation."}</p>
                </div>
              </li>

              <li className="guidance-item">
                <span className="item-bullet alert">🚨</span>
                <div>
                  <strong>Low Pulse Rate (&lt; 50 BPM Bradycardia Emergency):</strong>
                  <p>Pulse rate under 50 BPM triggers phone emergency siren alarm, spoken voice warning, and 108 Ambulance alert.</p>
                </div>
              </li>

              <li className="guidance-item">
                <span className="item-bullet alert">🚫</span>
                <div>
                  <strong>Unhealthy Habits to Avoid:</strong>
                  <p>Skipping doctor prescribed medicines, consuming high sodium/salt food, or ignoring sudden dizziness.</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* ===================================================================
          4. LOW PULSE EMERGENCY MODAL POPUP
         =================================================================== */}
      <Modal
        isOpen={isLowPulseModalOpen}
        title={t.lowPulseAlarmTitle || "🚨 CRITICAL: Low Pulse Emergency Alarm!"}
        icon="🆘"
        onClose={() => setIsLowPulseModalOpen(false)}
        confirmText="Call Free Ambulance 108"
        cancelText="Close Alarm"
        onConfirm={() => {
          window.location.href = "tel:108";
        }}
      >
        <div style={{ textAlign: 'center', padding: '10px 0' }}>
          <p style={{ fontSize: '20px', fontWeight: '800', color: 'var(--red-alert)', marginBottom: '12px' }}>
            Current Pulse Rate: {heartRate} BPM (Bradycardia Risk)
          </p>

          <p style={{ fontSize: '17px', color: 'var(--text-primary)', marginBottom: '20px', lineHeight: '1.5' }}>
            {t.lowPulseAlarmMsg || "Your pulse is dangerously low. Please sit down immediately, rest, and call for emergency support."}
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <a 
              href="tel:108" 
              className="btn-modal-ambulance-call primary"
              style={{ padding: '16px', fontSize: '19px' }}
            >
              🚑 Call 108 Free National Ambulance
            </a>

            <a 
              href="tel:112" 
              className="btn-modal-ambulance-call secondary"
              style={{ padding: '14px', fontSize: '18px' }}
            >
              🚨 Call 112 National Emergency
            </a>
          </div>
        </div>
      </Modal>
    </div>
  );
}

export default VitalsMonitor;

