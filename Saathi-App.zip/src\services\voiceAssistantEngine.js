// Multilingual Voice Assistant Engine
// Understands user intent and returns appropriate responses in the EXACT matching language (en, hi, bn, as).

import { detectLanguage } from './languageDetector';

export async function processVoiceQuery(queryText, forceLang = null) {
  // Simulate natural AI thinking delay
  await new Promise((res) => setTimeout(res, 600));

  const text = queryText ? queryText.trim() : '';
  const detectedLang = forceLang || detectLanguage(text);
  const lowerText = text.toLowerCase();

  // Topic classification
  let topic = 'general';
  if (lowerText.includes('weather') || text.includes('मौसम') || text.includes('আবহাওয়া') || text.includes('বতৰ') || lowerText.includes('mausam')) {
    topic = 'weather';
  } else if (lowerText.includes('medicine') || text.includes('दवा') || text.includes('ওষুধ') || text.includes('ঔষধ') || lowerText.includes('dawai') || lowerText.includes('prescription')) {
    topic = 'medicine';
  } else if (lowerText.includes('ambulance') || lowerText.includes('emergency') || text.includes('इमरजेंसी') || text.includes('अस्पताल') || text.includes('জরুরি') || text.includes('জৰুৰী')) {
    topic = 'emergency';
  } else if (lowerText.includes('family') || lowerText.includes('son') || lowerText.includes('daughter') || text.includes('परिवार') || text.includes('পরিবার') || text.includes('পৰিয়াল')) {
    topic = 'family';
  }

  let answer = '';

  // 1. ENGLISH RESPONSE
  if (detectedLang === 'en') {
    if (topic === 'weather') {
      answer = "Today's weather is pleasant and sunny at 28°C. Perfect for a gentle morning walk!";
    } else if (topic === 'medicine') {
      answer = "You have 5 scheduled medicines today. 4 taken and 1 upcoming at 9:00 PM (Diabetes Care).";
    } else if (topic === 'emergency') {
      answer = "Free Emergency Ambulance 108 is available 24x7. Press Need Help button to call immediately.";
    } else if (topic === 'family') {
      answer = "Your caregiver Ramesh Sharma is connected. All medicine logs are synced to your family dashboard.";
    } else {
      answer = `I understood your request: "${text}". How else can I assist your health and daily schedule today?`;
    }
  }

  // 2. HINDI RESPONSE
  else if (detectedLang === 'hi') {
    if (topic === 'weather') {
      answer = "आज का मौसम सुहावना और धूप वाला है, तापमान 28°C है। हल्की सैर के लिए बहुत अच्छा दिन है!";
    } else if (topic === 'medicine') {
      answer = "आपकी आज 5 दवाइयाँ तय हैं। 4 ली जा चुकी हैं और रात 9:00 बजे 1 दवा बाकी है।";
    } else if (topic === 'emergency') {
      answer = "मुफ़्त आपातकालीन एम्बुलेंस 108 उपलब्ध है। तुरंत कॉल करने के लिए 'मदद चाहिए' बटन दबाएं।";
    } else if (topic === 'family') {
      answer = "आपके बेटे रमेश शर्मा का संपर्क एक्टिव है। आज की सभी दवाइयों का विवरण सहेजा गया है।";
    } else {
      answer = `मैंने आपका सवाल समझा: "${text}"। बताइए मैं आज आपकी स्वास्थ्य देखभाल में और क्या मदद कर सकती हूँ?`;
    }
  }

  // 3. BENGALI RESPONSE
  else if (detectedLang === 'bn') {
    if (topic === 'weather') {
      answer = "আজকের আবহাওয়া খুব মনোরম এবং রোদঝলমলে, তাপমাত্রা ২৮°সে। সকালে একটু হাঁটার জন্য চমৎকার দিন!";
    } else if (topic === 'medicine') {
      answer = "আপনার আজ ৫টি ওষুধ রয়েছে। ৪টি নেওয়া হয়েছে এবং রাত ৯:০০ টায় ১টি বাকি আছে।";
    } else if (topic === 'emergency') {
      answer = "বিনামূল্যে জরুরি অ্যাম্বুলেন্স ১০৮ ২৪ ঘণ্টা উপলব্ধ। এখনই কল করতে 'সাহায্য চাই' বোতাম টিপুন।";
    } else if (topic === 'family') {
      answer = "আপনার ছেলে রমেশ শর্মার সঙ্গে যোগাযোগ রয়েছে। আজকের ওষুধের সমস্ত তথ্য পরিবারে সংরক্ষিত।";
    } else {
      answer = `আমি আপনার প্রশ্ন বুঝতে পেরেছি: "${text}"। বলুন আজ আপনার স্বাস্থ্য ও দিনের কাজে কীভাবে সাহায্য করতে পারি?`;
    }
  }

  // 4. ASSAMESE RESPONSE
  else if (detectedLang === 'as') {
    if (topic === 'weather') {
      answer = "আজিৰ বতৰ অতি মনোৰম আৰু ৰ'দঘাই, উত্তাপ ২৮° ছে। ৰাতিপুৱাৰ ভ্ৰমণৰ বাবে বৰ ভাল দিন!";
    } else if (topic === 'medicine') {
      answer = "আপোনাৰ আজি ৫ টা ঔষধ আছে। ৪ টা লোৱা হ'ল আৰু ৰাতি ৯:০০ বজাত ১ টা বাকী আছে।";
    } else if (topic === 'emergency') {
      answer = "বিনামূলীয়া জৰুৰীকালীন এম্বুলেন্স ১০৮ উপলব্ধ। এতিয়াই কল কৰিবলৈ 'সহায় লাগে' বটম টিপক।";
    } else if (topic === 'family') {
      answer = "আপোনাৰ পুত্ৰ ৰমেশ শৰ্মাৰ সৈতে সংযোগ আছে। আজিৰ সকলো ঔষধৰ তথ্য সংৰক্ষিত হ'ল।";
    } else {
      answer = `মই আপোনাৰ প্ৰশ্ন বুজি পালোঁ: "${text}"। কওক আজি আপোনাৰ স্বাস্থ্য আৰু কাৰ্য্যসূচীত কেনেকৈ সহায় কৰিব পাৰোঁ?`;
    }
  }

  return {
    queryText: text,
    answer,
    detectedLang,
    topic
  };
}
